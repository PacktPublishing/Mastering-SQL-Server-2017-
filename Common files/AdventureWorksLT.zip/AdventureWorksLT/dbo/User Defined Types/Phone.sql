﻿CREATE TYPE [dbo].[Phone]
    FROM NVARCHAR (25) NULL;

